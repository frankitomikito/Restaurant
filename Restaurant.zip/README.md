<<<<<<< HEAD
# Restaurant
bilatoten
=======
# Restaurant-Table-Reservation
A restaurant table booking system, by which customer can book a table and can order food menu for their meal, from any registered restaurant of this system. For this system there are two types of user. First one is restaurant authority, at first they have to register to this system and have to provide their food menu and price for the menu. And the second one is the customer for the restaurant. To book a table of a restaurant, customer must have to register at this system. To register this system customer have to provide their name, phone number and email. Then they will be able to choose a restaurant and select a table for the restaurant. They also have to choose the food menu from that restaurant's provide menu. They also have to provide the time when they want to come to take their meal. Then they have to pay the cost of the meal by BKash or Rocket or other payment method that the system accept. After payment customer will get a conformation E-Mail to his email.
>>>>>>> First Message
